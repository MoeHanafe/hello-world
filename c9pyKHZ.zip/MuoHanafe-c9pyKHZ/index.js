//console.log("Hello from JavaScript");
//var 
//let
//const 
//var name = 'Moe';
// let name = "Moe";
//let Name = 'hanafe';

//let ex = 'string';
//let ex2 = 'string';
//console.log(ex+' 'ex2);
//console.log`${ex} ${ex2}`;

//let num = 1;
//let num2 = 1.11111;
//console.log(parlseFloat(num2))
//console.log(parseInt(num2))
//console.log(num2. toFixed)
 
//let ex = true;
//let ex2 = false;
// let ex3 = null;
//let ex4 = -2;
//let ex5 = undefiened;
//let example = NaN;
//console.log(Boolean(ex));